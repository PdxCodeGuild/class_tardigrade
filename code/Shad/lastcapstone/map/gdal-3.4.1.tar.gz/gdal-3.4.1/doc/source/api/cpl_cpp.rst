.. _cpl_cpp_api:

================================================================================
Common Portability Library C++ API
================================================================================

cpl_odbc.h
----------

.. doxygenfile:: cpl_odbc.h
   :project: api

cpl_vsi_virtual.h
-----------------

.. doxygenfile:: cpl_vsi_virtual.h
   :project: api

.. seealso::

   :ref:`cpl_api`.
