.. _raster.dipex:

================================================================================
DIPEx -- ELAS DIPEx
================================================================================

.. shortname:: DIPEx

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/raw/dipxdataset.cpp``.

Driver capabilities
-------------------

.. supports_georeferencing::

.. supports_virtualio::
