.. _gdal_rasterband_cpp:

================================================================================
GDALRasterBand C++ API
================================================================================

.. doxygenclass:: GDALRasterBand
   :project: api
   :members:
   :protected-members:
