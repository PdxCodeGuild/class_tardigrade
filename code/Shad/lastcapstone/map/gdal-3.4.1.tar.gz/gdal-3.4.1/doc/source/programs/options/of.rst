.. option:: -of <format>

    Select the output format. Starting with GDAL 2.3, if not specified, the
    format is guessed from the extension (previously was GTiff). Use the short
    format name.
