.. _raster.coasp:

================================================================================
COASP --  DRDC COASP SAR Processor Raster
================================================================================

.. shortname:: COASP

.. built_in_by_default::

NOTE: Implemented as ``gdal/frmts/coasp/coasp_dataset.cpp``.

